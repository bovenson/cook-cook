---
name: Feature request
about: Suggest an idea for this project

---

**Is your feature request related to a problem? (你需要的功能是否与某个问题有关?)**


**Describe the solution you'd like (描述你期望的解决方法)**


**Describe alternatives you've considered (描述你想到的折衷方案)**


**Additional context/screenshots (更多上下文/截图)**

